from django.conf.urls import url
from upload_image import views

urlpatterns=[
            url('img/', views.upl_img),
            url('apr/(?P<idd>\w+)', views.apprv),
            url('rej/(?P<idd>\w+)', views.reja),
            url('user_image/',views.image_user),
            url('status_verify/',views.verify_status)
]