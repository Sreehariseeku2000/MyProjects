from django.db import models
from user_reg.models import UserReg
from vehicle.models import Vehicle
# Create your models here.

class UploadeImage(models.Model):
    upload_image_id = models.AutoField(primary_key=True)
    #user_id = models.IntegerField()
    user=models.ForeignKey(UserReg,on_delete=models.CASCADE)
    #vehicle_id = models.IntegerField()
    vehicle=models.ForeignKey(Vehicle,on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    action = models.CharField(max_length=45)
    up_img_2 = models.CharField(max_length=45)
    upload_image3 = models.CharField(max_length=45)
    upload_image4 = models.CharField(max_length=45)
    upload_image5 = models.CharField(max_length=45)
    upload_image6 = models.CharField(max_length=45)
    upload_image1 = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'uploade_image'
