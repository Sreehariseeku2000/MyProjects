from django.db import models
from user_reg.models import UserReg
from booking.models import Booking
# Create your models here.

class Payment(models.Model):
    payment_id = models.AutoField(primary_key=True)
    amout = models.IntegerField()
    cvv = models.IntegerField()
    cardholder_name = models.CharField(max_length=45)
    #user_id = models.IntegerField()
    user=models.ForeignKey(UserReg, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    # booking_id = models.IntegerField()
    booking=models.ForeignKey(Booking, on_delete=models.CASCADE)


    class Meta:
        managed = False
        db_table = 'payment'
