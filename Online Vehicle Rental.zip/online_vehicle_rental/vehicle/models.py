from django.db import models

# Create your models here.
class Vehicle(models.Model):
    vehicle_id = models.AutoField(primary_key=True)
    registration_no = models.CharField(db_column='Registration_No', max_length=45)  # Field name made lowercase.
    type = models.CharField(db_column='Type', max_length=45)  # Field name made lowercase.
    vehicle_model = models.CharField(db_column='Vehicle_Model', max_length=45)  # Field name made lowercase.
    vehicle_type = models.CharField(db_column='Vehicle_Type', max_length=45)  # Field name made lowercase.
    fuel = models.CharField(db_column='Fuel', max_length=45)  # Field name made lowercase.
    image = models.CharField(max_length=450)
    price = models.CharField(max_length=45)
    vehicle_no = models.CharField(max_length=45)

    latitude = models.CharField(max_length=45)
    longitude = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'vehicle'

