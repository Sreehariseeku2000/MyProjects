from django.conf.urls import url
from booking import views

urlpatterns=[
        url('boo/', views.book),
        url('apr/(?P<idd>\w+)', views.apprv),
        url('rej/(?P<idd>\w+)', views.reja),
        url('veh_book/(?P<idd>\w+)',views.book_veh_user),
        url('book_status_view/',views.view_book_status),
        url('paidbook/',views.view_paid_booking)
]