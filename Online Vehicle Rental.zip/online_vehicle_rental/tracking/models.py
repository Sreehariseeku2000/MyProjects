from django.db import models

# Create your models here.

# class Tracking(models.Model):
#     tracking_id = models.AutoField(primary_key=True)
#     vehicle_no = models.CharField(max_length=45)
#     lattitude = models.IntegerField()
#     longitude = models.IntegerField()
#
#     class Meta:
#         managed = False
#         db_table = 'tracking'
