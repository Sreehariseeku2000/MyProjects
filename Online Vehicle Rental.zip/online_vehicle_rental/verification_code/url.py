from django.conf.urls import url
from verification_code import views

urlpatterns=[
               url('vericode/(?P<idd>\w+)', views.verif),
               url('code_view/',views.view_code)
]