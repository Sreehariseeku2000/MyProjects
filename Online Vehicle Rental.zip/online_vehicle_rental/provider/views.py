from django.shortcuts import render

from login.models import Login
from provider.models import Provider

# Create your views here.
def pro_view(request):
    obj=Provider.objects.all()
    context={
        'x':obj
    }
    return render(request, 'provider/provider(Admin).html',context)
def prv_reg(request):
    if request.method=='POST' :
        obj=Provider()
        obj.name=request.POST.get('nam')
        obj.email=request.POST.get('mail')
        obj.gender=request.POST.get('gnd')
        obj.contact_no=request.POST.get('cnum')
        obj.service_location=request.POST.get('name')
        obj.pin=request.POST.get('pin')
        obj.district=request.POST.get('dis')
        obj.password=request.POST.get('pass')
        obj.save()

        ob = Login()
        ob.username = obj.name
        ob.password = obj.password
        ob.uid = obj.provider_id
        ob.type = 'service_provider'
        ob.save()
    return render(request, 'provider/provider.html')


def view_provider(request):
    obj=Provider.objects.all()
    context={
        'x':obj
    }
    return render(request,'provider/provider(User).html',context)