from django.conf.urls import url
from temp import views

urlpatterns=[
             url('admin_page/', views.admin),
             url('home_page/',views.home),
             url('logistics_page/',views.logistics),
             url('service_provider_page/',views.service_provider),
             url('user_page/',views.user),
             url('veh/', views.veh_view)
]