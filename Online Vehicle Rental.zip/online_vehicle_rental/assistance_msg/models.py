from django.db import models
from user_reg.models import UserReg
from booking.models import Booking
# Create your models here.

class AssistanceMsg(models.Model):
    assistance_msg_id = models.AutoField(primary_key=True)
    message = models.CharField(max_length=45)
    action = models.CharField(max_length=45)
    # user_id = models.IntegerField()
    user=models.ForeignKey(UserReg, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    #booking_id = models.IntegerField()
    booking=models.ForeignKey(Booking,on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'assistance_msg'
