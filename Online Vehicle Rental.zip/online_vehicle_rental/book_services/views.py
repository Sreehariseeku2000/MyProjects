from django.shortcuts import render
from book_services.models import BookServices
from vehicle.models import Vehicle
from booking.models import Booking
# Create your views here.
def book_sev(request):
    obj=BookServices.objects.all()
    context={
        'x':obj
    }
    return render(request, 'book_services/view_Service_book(Service_provider).html',context)

def post_book(request,idd):
    ob=Vehicle.objects.all()
    context={
        'x':ob
    }
    if request.method=='POST':
        obj=BookServices()
        obj.vehicle_id=request.POST.get('vehicle')
        obj.type='admin'
        obj.service_id=idd
        obj.book_date=request.POST.get('dte')
        obj.time=request.POST.get('tim')
        obj.save()
    return render(request, 'book_services/book_service.html',context)

def user_book(request,idd):
    ss=request.session["uid"]
    ob=Booking.objects.filter(user_id=ss)
    vehicle_ids = ob.values_list('vehicle_id', flat=True)
    unique_vehicle_ids = set(vehicle_ids)
    vob=Vehicle.objects.filter(vehicle_id__in=unique_vehicle_ids)
    context={
        'x':vob
    }
    if request.method=='POST':
        obj=BookServices()
        obj.user_id=ss
        obj.type='user'
        obj.vehicle_id=request.POST.get('vehicle')
        obj.service_id=idd
        obj.book_date=request.POST.get('dte')
        obj.time=request.POST.get('tim')
        obj.save()
    return render(request,'book_services/book_service_user.html',context)

