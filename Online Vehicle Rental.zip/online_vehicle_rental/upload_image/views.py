from django.shortcuts import render
from upload_image.models import UploadeImage
from django.core.files.storage import FileSystemStorage
import datetime
# Create your views here.
def upl_img(request):
    obj=UploadeImage.objects.all()
    context={
        'x':obj
    }
    return render(request, 'upload_image/Upload_image(Admin).html',context)


def apprv(request,idd):
    obj=UploadeImage.objects.get(upload_image_id=idd)
    obj.action='Approved'
    obj.save()
    return upl_img(request)
def reja(request,idd):
    obj=UploadeImage.objects.get(upload_image_id=idd)
    obj.action='Rejected'
    obj.save()
    return upl_img(request)


def image_user(request):
    ss=request.session["uid"]
    if request.method=='POST':
        obj=UploadeImage()
        obj.vehicle_id=1
        obj.user_id=ss
        obj.action='pending'
        #obj.upload_image1=request.POST.get('u1')
        myfile = request.FILES['u1']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.upload_image1 = myfile.name
        #obj.up_img_2=request.POST.get('u2')
        myfile = request.FILES['u2']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.up_img_2 = myfile.name
        #obj.upload_image3=request.POST.get('u3')
        myfile = request.FILES['u3']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.upload_image3 = myfile.name
        #obj.upload_image4=request.POST.get('u4')
        myfile = request.FILES['u4']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.upload_image4 = myfile.name
        #obj.upload_image5=request.POST.get('u5')
        myfile = request.FILES['u5']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.upload_image5 = myfile.name
        #obj.upload_image6=request.POST.get('u6')
        myfile = request.FILES['u6']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.upload_image6 = myfile.name
        obj.date=datetime.datetime.today()
        obj.time=datetime.datetime.now()
        obj.save()
    return render(request,'upload_image/uploadimage.html')

def verify_status(request):
    obj=UploadeImage.objects.all()
    context={
        'x':obj
    }
    return render(request,'upload_image/Verify_Upload_picture(User).html',context)