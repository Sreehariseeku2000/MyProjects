from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from vehicle.models import Vehicle
from django.db.models import Q
# Create your views here.
def veh_adm(request):
    obj=Vehicle.objects.all()
    context={
        'x':obj
    }
    return render(request, 'vehicle/manage_vehicle(Admin).html',context)



def update_adm(request,idd):
    obj = Vehicle.objects.get(vehicle_id=idd)
    context = {
        'x': obj
    }
    if request.method=='POST' :
        obj=Vehicle.objects.get(vehicle_id=idd)
        obj.registration_no=request.POST.get('rgname')
        obj.type = request.POST.get('type')
        obj.vehicle_model = request.POST.get('vmodel')
        obj.vehicle_type= request.POST.get('vtype')
        obj.fuel= request.POST.get('Fuel')
        #obj.image=request.POST.get('img')
        myfile = request.FILES['img']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.image = myfile.name
        obj.price=request.POST.get('pri')
        obj.save()
        return veh_add(request)
    return render(request,'vehicle/update_admin.html', context)

def dlt_adm(request,idd):
    obj=Vehicle.objects.get(vehicle_id=idd)
    obj.delete()
    return veh_adm(request)

def veh_logi(request):
    obj=Vehicle.objects.all()
    context={
        'x':obj
    }
    return render(request, 'vehicle/Manage_Vehicleee(Logistics).html',context)


def search(request):
    if request.method=='POST':
        vv=request.POST.get('lop')
        obj = Vehicle.objects.filter(Q(vehicle_model__contains=vv)| Q(vehicle_type__contains=vv))
        context = {
            'x': obj
        }
        return render(request, 'vehicle/search.html', context)
    else:
        obj=Vehicle.objects.all()
        context={
            'x':obj
        }
    return render(request, 'vehicle/search.html',context)


def log_upd(request,idd):
    obj = Vehicle.objects.get(vehicle_id=idd)
    context = {
        'x': obj
    }
    if request.method=='POST' :
        obj=Vehicle.objects.get(vehicle_id=idd)
        obj.registration_no=request.POST.get('rgname')
        obj.type = request.POST.get('type')
        obj.vehicle_model = request.POST.get('vmodel')
        obj.vehicle_type= request.POST.get('vtype')
        obj.fuel= request.POST.get('Fuel')
        #obj.image=request.POST.get('img')
        myfile = request.FILES['img']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.image = myfile.name
        obj.price = request.POST.get('pri')
        obj.save()
        return veh_logi(request)
    return render(request,'vehicle/update_logistics.html', context)

def dlt_log(request,idd):
    obj=Vehicle.objects.get(vehicle_id=idd)
    obj.delete()
    return veh_logi(request)

def veh_add(request):
    if request.method=='POST' :
        obj=Vehicle()
        obj.registration_no=request.POST.get('rgname')
        obj.type = request.POST.get('type')
        obj.vehicle_model = request.POST.get('vmodel')
        obj.vehicle_type= request.POST.get('vtype')
        obj.fuel= request.POST.get('Fuel')
        #obj.image=request.POST.get('img')
        myfile = request.FILES['img']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.image = myfile.name
        obj.price = request.POST.get('pri')
        obj.vehicle_no=request.POST.get('vno')
        obj.latitude='pending'
        obj.longitude='pending'
        obj.save()
    return render(request, 'vehicle/vehicle.html')

def view_vehicle(request):
    obj=Vehicle.objects.all()
    context={
        'x':obj
    }
    return render(request,'vehicle/view_vehicle(User).html',context)

def view_map(request):
    obj=Vehicle.objects.all()
    context={
        'x':obj
    }
    return render(request,'vehicle/view_veh_map.html',context)