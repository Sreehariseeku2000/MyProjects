from django.db import models

# Create your models here.


class Logistics(models.Model):
    logistics_id = models.AutoField(primary_key=True)
    name = models.CharField(db_column='Name', max_length=45)  # Field name made lowercase.
    gender = models.CharField(db_column='Gender', max_length=45)  # Field name made lowercase.
    contact_number = models.CharField(db_column='Contact_number', max_length=45)  # Field name made lowercase.
    email = models.CharField(db_column='Email', max_length=45)  # Field name made lowercase.
    place = models.CharField(db_column='Place', max_length=45)  # Field name made lowercase.
    pin = models.CharField(db_column='Pin', max_length=45)  # Field name made lowercase.
    district = models.CharField(db_column='District', max_length=45)  # Field name made lowercase.
    age = models.CharField(max_length=45)
    dob = models.CharField(max_length=45)
    house_name = models.CharField(max_length=45)
    location = models.CharField(max_length=45)
    password = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'logistics'
