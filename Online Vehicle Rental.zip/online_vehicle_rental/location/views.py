from django.shortcuts import render
from location.models import Location
# Create your views here.
def loc(request):
    obj=Location.objects.all()
    context={
        'x':obj
    }
    return render(request, 'location/Location(Admin).html',context)