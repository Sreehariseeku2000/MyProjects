from django.shortcuts import render
from booking.models import Booking
from vehicle.models import Vehicle
# Create your views here.
def book(request):
    obj=Booking.objects.all()
    context={
        'x':obj
    }
    return render(request, 'booking/Manage_booking(Admin).html',context)


def apprv(request,idd):
    obj=Booking.objects.get(booking_id=idd)
    obj.status='Approved'
    obj.save()
    return book(request)
def reja(request,idd):
    obj=Booking.objects.get(booking_id=idd)
    obj.status='Rejected'
    obj.save()
    return book(request)

def book_veh_user(request,idd):
    ss=request.session["uid"]
    obb=Vehicle.objects.get(vehicle_id=idd)
    context={
        'y':obb
    }
    if request.method=='POST':
         obj=Booking()
         obj.vehicle_id=idd
         obj.user_id=ss
         obj.status = 'pending'
         obj.date= request.POST.get('dte')
         obj.time= request.POST.get('tim')
         obj.save()
    return render(request,'booking/booking_user.html', context)

def view_book_status(request):
    ss=request.session["uid"]
    obj=Booking.objects.filter(user_id=ss)
    context={
        'x':obj
    }
    return render(request,'booking/view_Booking_status(User).html',context)

def view_paid_booking(request):
    obj=Booking.objects.filter(status='paid')
    context={
        'x':obj
    }
    return render(request,'booking/admin_view_paid_booking.html',context)