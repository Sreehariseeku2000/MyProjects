from django.conf.urls import url
from payment import views

urlpatterns=[
             url('paym/', views.pay),
             url('paymn/(?P<idd>\w+)',views.pay_veh)
]