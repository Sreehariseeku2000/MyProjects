from django.shortcuts import render
from payment.models import Payment
from booking.models import Booking
import datetime
# Create your views here.
def pay(request):
    obj=Payment.objects.all()
    context={
        'x':obj
    }
    return render(request, 'payment/payment(Admin).html',context)

def pay_veh(request,idd):
    ss=request.session["uid"]
    obb=Booking.objects.get(booking_id=idd)
    context={
        'z':obb
    }
    if request.method=='POST':
        if Payment.objects.filter(booking_id=idd).exists():
            message="Already paid"
        else:
            obj=Payment()
            obj.user_id=ss
            obj.booking_id=idd
            obj.amout=request.POST.get('amount')
            obj.cvv=request.POST.get('cvv')
            obj.cardholder_name=request.POST.get('cdholder')
            obj.date=datetime.datetime.today()
            obj.time=datetime.datetime.now()
            obj.save()
            ob=Booking.objects.get(booking_id=idd)
            ob.status='paid'
            ob.save()
            message="Payment successfull..."
        context={
            'msg':message,
            'z':obb
        }
    return render(request,'payment/payment.html',context)