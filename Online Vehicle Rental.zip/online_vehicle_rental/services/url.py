from django.conf.urls import url
from services import views

urlpatterns=[
               url('admin/', views.ser_adm),
               url('add_ser/', views.ser_add),
               url('sev_book/',views.book_sev)
]
