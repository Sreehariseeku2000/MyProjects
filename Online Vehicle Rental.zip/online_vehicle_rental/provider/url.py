from django.conf.urls import url
from provider import views

urlpatterns=[
          url('view_pro/', views.pro_view),
          url('reg_prv/', views.prv_reg),
          url('provider_view/',views.view_provider)
]
