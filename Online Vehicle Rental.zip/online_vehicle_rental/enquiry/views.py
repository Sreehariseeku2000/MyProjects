from django.shortcuts import render
from enquiry.models import Enquiry
import datetime
# Create your views here.
def enqu_view(request):
    obj=Enquiry.objects.all()
    context={
        'x':obj
    }
    return render(request, 'enquiry/enquiry(Admin).html',context)
def enqu_rep(request,idd):
    if request.method=='POST':
        obj=Enquiry.objects.get(enquiry_id=idd)
        obj.reply=request.POST.get('reply')
        obj.save()
        return enqu_view(request)
    return render(request, 'enquiry/enquiryreplay.html')

def enqu_post(request):
     ss=request.session["uid"]
     if request.method=='POST':
         obj=Enquiry()
         obj.user_id=ss
         obj.description=request.POST.get('desp')
         obj.date=datetime.datetime.today()
         obj.time=datetime.datetime.now()
         obj.save()
     return render(request,'enquiry/enquirypost.html')

def view_enq_msg(request):
    ss=request.session["uid"]
    obj=Enquiry.objects.filter(user_id=ss)
    context={
        'x':obj
    }
    return render(request,'enquiry/view_Enquiry_replay(User).html',context)