from django.conf.urls import url
from assistance_msg import views

urlpatterns=[
    url('adm_msg_view/', views.view_msg_adm),
    url('msg_rply/(?P<idd>\w+)', views.replay_msg),
    url('snd_msg/(?P<idd>\w+)',views.msg_snd),
    url('msg_view/',views.view_msg)

]