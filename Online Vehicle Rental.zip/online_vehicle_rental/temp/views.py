from django.shortcuts import render
from vehicle.models import Vehicle
# Create your views here.


def admin(request):

    return render(request,'temp/admin.html')

def home(request):

    return render(request,'temp/home.html')

def logistics(request):

    return render(request,'temp/logistics.html')

def service_provider(request):

    return render(request,'temp/service provider.html')

def user(request):
    return render(request,'temp/user.html')



def veh_view(request):
    ob=Vehicle.objects.all()
    context={
        'x':ob
    }
    return render(request, 'temp/user.html',context)