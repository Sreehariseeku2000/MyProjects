from django.apps import AppConfig


class AssistanceMsgConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'assistance_msg'
