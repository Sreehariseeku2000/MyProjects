from django.db import models
from user_reg.models import UserReg
from vehicle.models import Vehicle
# Create your models here.

class Location(models.Model):
    location_id = models.AutoField(primary_key=True)
    #vehicle_id = models.IntegerField()
    vehicle=models.ForeignKey(Vehicle,on_delete=models.CASCADE)
    #user_id = models.IntegerField()
    user=models.ForeignKey(UserReg,on_delete=models.CASCADE)
    lattitude = models.IntegerField()
    longitude = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'location'
