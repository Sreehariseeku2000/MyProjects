from django.shortcuts import render

from login.models import Login
from logistics.models import Logistics
# Create your views here.
def logis(request):
    if request.method=='POST':
        obj=Logistics()
        obj.name= request.POST.get('name')
        obj.gender= request.POST.get('gnd')
        obj.contact_number= request.POST.get('cnum')
        obj.email= request.POST.get('mail')
        obj.place = request.POST.get('pla')
        obj.pin= request.POST.get('pin')
        obj.district= request.POST.get('dis')
        obj.age=request.POST.get('age')
        obj.dob=request.POST.get('dob')
        obj.house_name= request.POST.get('hm')
        obj.location =request.POST.get('loc')
        obj.password=request.POST.get('pass')
        obj.save()

        ob = Login()
        ob.username = obj.name
        ob.password = obj.password
        ob.uid = obj.logistics_id
        ob.type = 'logistics'
        ob.save()
    return render(request, 'logistics/logistics.html')
