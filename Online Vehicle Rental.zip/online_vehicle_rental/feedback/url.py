from django.conf.urls import url
from feedback import views

urlpatterns=[
           url('feed_b/', views.feed),
           url('feed_post/(?P<idd>\w+)',views.post_feed)
]