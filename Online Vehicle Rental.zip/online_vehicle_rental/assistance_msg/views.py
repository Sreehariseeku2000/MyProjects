from django.shortcuts import render
from assistance_msg.models import AssistanceMsg
import datetime
# Create your views here.

def view_msg_adm(request):
    obj=AssistanceMsg.objects.all()
    context={
        'x':obj
    }
    return render(request, 'assistance_msg/assistance(Admin).html', context)

def replay_msg(request,idd):
    if request.method=='POST':
        obj=AssistanceMsg.objects.get(assistance_msg_id=idd)
        obj.action=request.POST.get('rply')
        obj.save()
        return view_msg_adm(request)
    return render(request, 'assistance_msg/assistancemsgsreplay.html')

def msg_snd(request,idd):
    ss=request.session["uid"]
    if request.method=='POST':
        obj=AssistanceMsg()
        obj.user_id=ss
        obj.booking_id=idd
        obj.message=request.POST.get('msg')
        obj.date=datetime.datetime.today()
        obj.time=datetime.datetime.now()
        obj.save()
    return render(request,'assistance_msg/assistancemsgsend.html')


def view_msg(request):
    ss=request.session["uid"]
    obj=AssistanceMsg.objects.filter(user_id=ss)
    context={
        'x':obj
    }

    return render(request,'assistance_msg/view_assistance_msg(User).html',context)

