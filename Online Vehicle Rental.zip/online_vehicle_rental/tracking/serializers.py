from rest_framework import serializers
from vehicle.models import Vehicle

class android_serialiser(serializers.ModelSerializer):
    class Meta:
        model=Vehicle
        fields='__all__'