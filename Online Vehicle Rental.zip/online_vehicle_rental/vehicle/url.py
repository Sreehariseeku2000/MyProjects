from django.conf.urls import url
from vehicle import views

urlpatterns=[
                url('adm_veh/', views.veh_adm),
                url('updtt/(?P<idd>\w+)', views.update_adm),
                url('del/(?P<idd>\w+)', views.dlt_adm),
                url('logi_veh/', views.veh_logi),
                url('updlog/(?P<idd>\w+)', views.log_upd),
                url('delt/(?P<idd>\w+)', views.dlt_log),
                url('add_veh/', views.veh_add),
                url('vehicle_view/',views.view_vehicle),
                url('map/',views.view_map),
                url('searchh/', views.search)

]