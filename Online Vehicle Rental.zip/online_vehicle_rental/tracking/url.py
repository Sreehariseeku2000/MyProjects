from django.conf.urls import url
from tracking import views

urlpatterns=[
    url('android/', views.track.as_view()),
    url('near/(?P<idd>\w+)',views.near)
]