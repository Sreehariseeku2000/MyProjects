from django.apps import AppConfig


class VerificationCodeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'verification_code'
