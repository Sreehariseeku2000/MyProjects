from django.conf.urls import url
from logistics import views

urlpatterns=[
             url('logist/', views.logis)
]