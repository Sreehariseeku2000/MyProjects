from django.conf.urls import url
from enquiry import views

urlpatterns=[
                 url('view_enqu/', views.enqu_view),
                 url('user_enqu/', views.view_enq_msg),
                 url('post_enqu/', views.enqu_post),
                 url('ap/(?P<idd>\w+)', views.enqu_rep)

]