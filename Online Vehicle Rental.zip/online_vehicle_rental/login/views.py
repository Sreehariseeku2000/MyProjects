from django.http import HttpResponseRedirect
from django.shortcuts import render
from login.models import Login

# Create your views here.
def log(request):
    if request.method=="POST":
        uname=request.POST.get("unm")
        PASSWORD=request.POST.get("psw")
        obj=Login.objects.filter(username=uname,password=PASSWORD)
        print(len(obj))
        tp=""
        for ob in obj:
            tp=ob.type
            uid=ob.uid
            if tp=="admin":
                request.session["uid"]=uid
                return HttpResponseRedirect('/temp/admin_page/')
            elif tp=="user":
                request.session["uid"]=uid
                return HttpResponseRedirect('/temp/user_page/')
            elif tp == "logistics":
                request.session["uid"] = uid
                return HttpResponseRedirect('/temp/logistics_page/')
            elif tp == "service_provider":
                request.session["uid"] = uid
                return HttpResponseRedirect('/temp/service_provider_page/')
            else:
                objlist="username or password incorrect...please try again....!"
                context={
                    'msg':objlist
                }
                return render(request,'login/login.html',context)
    return render(request, 'login/login.html')