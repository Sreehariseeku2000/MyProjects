from django.conf.urls import url
from user_reg import views

urlpatterns=[
    url('user_r/',views.user),
    url('apr/(?P<idd>\w+)',views.apprv),
    url('reja/(?P<idd>\w+)',views.rej),
    url('regis_user/', views.user_regis),
    url('pro_update/',views.update_pro)

]