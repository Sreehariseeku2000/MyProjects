from django.shortcuts import render
from feedback.models import Feedback
import datetime
# Create your views here.
def feed(request):
    obj=Feedback.objects.all()
    context={
        'x':obj
    }
    return render(request, 'feedback/view_feedback(Service_provider).html',context)

def post_feed(request,idd):
       ss=request.session["uid"]
       if request.method=='POST':
           obj=Feedback()
           obj.user_id=ss
           obj.booking_id=idd
           obj.feedback=request.POST.get('fdbck')
           obj.date=datetime.datetime.today()
           obj.time=datetime.datetime.now()
           obj.save()
       return render(request,'feedback/feedback.html')