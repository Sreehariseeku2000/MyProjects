from django.shortcuts import render
from verification_code.models import VerificationCode
from django.http import HttpResponseRedirect
from booking.models import Booking
import datetime
import smtplib
# Create your views here.
def verif(request,idd):
    if VerificationCode.objects.filter(booking_id=idd).exists():
        obj=VerificationCode.objects.get(booking_id=idd)
    else:
        obj=VerificationCode()
        obj.booking_id=idd
        obj.user_id=obj.booking.user_id
        obj.vehicle_id=obj.booking.vehicle_id
        obj.date = datetime.datetime.today()
        obj.time = datetime.datetime.now()
        obj.save()
    try:
        email = "projectmailbg@gmail.com"
        em=obj.user.email
        sub = "Verification Code"
        msg = "Hello "+obj.user.name+",\n Your Vehicle Booking is Successfull..\n" \
                                     "Vehicle Number:\t"+obj.vehicle.registration_no+"\nVerification Code:\t"+obj.verification_no+"\nThank You..Visit Again"

        text = f'subject : {sub} \n\n{msg}'
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(email, 'iqjjrhsyerovorav')
        server.sendmail(email, str(em), text)
        message="Successfully send"
    except:
        message = "Invalid username"
    obj = Booking.objects.filter(status='paid')
    context = {
        'x': obj,
        'msg': message
    }
    return render(request, 'booking/admin_view_paid_booking.html', context)

    # return HttpResponseRedirect('/booking/paidbook/')


def view_code(request):
    uid=request.session["uid"]
    obj=VerificationCode.objects.filter(user_id=uid)
    context={
        'x':obj
    }

    return render(request,'verification_code/verification_code(User).html',context)