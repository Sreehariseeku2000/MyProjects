from django.shortcuts import render
from services.models import Services
# Create your views here.
def ser_adm(request):
    obj=Services.objects.all()
    context={
        'x':obj
    }
    return render(request, 'services/services(admin).html',context)


def ser_add(request):
    ss=request.session['uid']
    if request.method=='POST':
        obj=Services()
        obj.vehicle_type=request.POST.get('type')
        obj.type_of_services = request.POST.get('ser')
        obj.provider_id=ss
        obj.save()
    return render(request, 'services/service.html')


def book_sev(request):
    obj=Services.objects.all()
    context={
        'x':obj
    }
    return render(request,'services/book_services(user).html',context)