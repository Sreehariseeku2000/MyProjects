"""online_vehicle_rental URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from temp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    url('assistance_msg/', include('assistance_msg.url')),
    url('book_services/', include('book_services.url')),
    url('booking/', include('booking.url')),
    url('enquiry/', include('enquiry.url')),
    url('feedback/', include('feedback.url')),
    url('location/', include('location.url')),
    url('login/', include('login.url')),
    url('logistics/', include('logistics.url')),
    url('payment/', include('payment.url')),
    url('provider/', include('provider.url')),
    url('services/', include('services.url')),
    url('track/', include('tracking.url')),
    url('upload_image/', include('upload_image.url')),
    url('user_reg', include('user_reg.url')),
    url('vehicle/', include('vehicle.url')),
    url('verification_code', include('verification_code.url')),
    url('temp/',include('temp.url')),
    url('$', views.home)

]
