from django.db import models
from user_reg.models import UserReg
from vehicle.models import Vehicle
# Create your models here.

class Booking(models.Model):
    booking_id = models.AutoField(db_column='Booking_id', primary_key=True)  # Field name made lowercase.
    status = models.CharField(db_column='Status', max_length=45)  # Field name made lowercase.
    #vehicle_id = models.IntegerField()
    vehicle=models.ForeignKey(Vehicle, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    #user_id = models.IntegerField()
    user=models.ForeignKey(UserReg,on_delete=models.CASCADE)
    class Meta:
        managed = False
        db_table = 'booking'

