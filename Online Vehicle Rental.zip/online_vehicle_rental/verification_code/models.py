from django.db import models
from user_reg.models import  UserReg
from vehicle.models import Vehicle
from booking.models import Booking
import random
import string
# Create your models here.

class VerificationCode(models.Model):
    verification_id = models.AutoField(primary_key=True)
    verification_no = models.CharField(db_column='verification_No', max_length=45,unique=True)  # Field name made lowercase.
    #user_id = models.IntegerField()
    user=models.ForeignKey(UserReg,on_delete=models.CASCADE)
    #vehicle_id = models.IntegerField()
    vehicle=models.ForeignKey(Vehicle,on_delete=models.CASCADE)
    booking=models.ForeignKey(Booking,on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()

    class Meta:
        managed = False
        db_table = 'verification_code'

    def save(self, *args, **kwargs):
        if not self.verification_no:
            # If you want to use random.choice with string.ascii_letters and string.digits
            random_string = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(6))

            self.verification_no = f"OVN-{random_string}"

        super().save(*args, **kwargs)