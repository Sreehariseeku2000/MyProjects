from django.shortcuts import render
from user_reg.models import UserReg
from django.core.files.storage import FileSystemStorage
from login.models import Login

# Create your views here.
def user(request):
    obj=UserReg.objects.all()
    context={
        'x':obj
    }
    return render(request,'user_reg/manage_user(admin).html', context)


def apprv(request,idd):
    obj=UserReg.objects.get(user_id=idd)
    obj.status='Approved'
    obj.save()
    ob=Login()
    ob.username=obj.name
    ob.password=obj.password
    ob.uid=obj.user_id
    ob.type='user'
    ob.save()
    return  user(request)


def rej(request,idd):
    obj=UserReg.objects.get(user_id=idd)
    obj.status='Rejected'
    obj.save()
    return  user(request)


def user_regis(request):
    if request.method=='POST':
        obj=UserReg()
        obj.name=request.POST.get('name')
        obj.age= request.POST.get('age')
        obj.gender= request.POST.get('gnd')
        obj.dob= request.POST.get('dob')
        obj.house_name= request.POST.get('hname')
        obj.place= request.POST.get('place')
        obj.pin= request.POST.get('pin')
        obj.district= request.POST.get('dis')
        obj.contact_no = request.POST.get('cnum')
        obj.email = request.POST.get('email')
        obj.license_no = request.POST.get('lnum')
        # obj.license_photo= request.POST.get('imageUpload[]')
        myfile=request.FILES['imageUpload[]']
        fs=FileSystemStorage()
        filename=fs.save(myfile.name,myfile)
        obj.license_photo=myfile.name
        #obj.license_photo1= request.POST.get('imageUpload1[]')
        myfile = request.FILES['imageUpload1[]']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.license_photo1= myfile.name
        obj.status='pending'
        obj.password=request.POST.get('pass')
        obj.save()
    return render(request,'user_reg/userreg.html')

def update_pro(request):
    ss=request.session["uid"]
    obj = UserReg.objects.get(user_id=ss)
    context = {
        'x': obj
    }
    if request.method=='POST':
        obj=UserReg.objects.get(user_id=ss)
        obj.name=request.POST.get('name')
        obj.age= request.POST.get('age')
        obj.gender= request.POST.get('gnd')
        obj.dob= request.POST.get('dob')
        obj.house_name= request.POST.get('hname')
        obj.place= request.POST.get('place')
        obj.pin= request.POST.get('pin')
        obj.district= request.POST.get('dis')
        obj.contact_no = request.POST.get('cnum')
        obj.email = request.POST.get('email')
        obj.license_no = request.POST.get('lnum')
        #obj.license_photo= request.POST.get('imageUpload[]')
        myfile = request.FILES['imageUpload[]']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.license_photo = myfile.name
        #obj.license_photo1= request.POST.get('imageUpload1[]')
        myfile = request.FILES['imageUpload1[]']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.license_photo1 = myfile.name
        obj.password = request.POST.get('pass')
        obj.save()
        obk=Login.objects.get(uid=request.session['uid'],type='user')
        obk.username=obj.name
        obk.password=obj.password
        obk.save()
    return render(request,'user_reg/updateprofile.html', context)