from django.http import HttpResponse
from django.shortcuts import render
# from tracking.models import Tracking

from vehicle.models import Vehicle
# Create your views here.
# def track(request):
#     obj=Tracking.objects.all()
#     context={
#         'x':obj
#     }
#     return render(request, 'tracking/track_vehicle(Admin).html',context)
#
#
# def track_veh(request):
#     obj=Tracking.objects.all()
#     context={
#         'x':obj
#     }
#
#     return render(request,'tracking/track_vehicle(User).html',context)

from rest_framework.views import APIView,Response
from tracking.serializers import android_serialiser

class track(APIView):
    def post(self,request):
        objs=Vehicle.objects.filter(vehicle_no=request.data['cno'])
        if len(objs)>0:
            obj=objs[0]
        else:
            obj=Vehicle.objects.get(vehicle_id=request.session['uid'])
        obj.vehicle_no=request.data['cno']
        obj.latitude=request.data['lat']
        obj.longitude=request.data['lon']
        obj.save()
        return HttpResponse('yes')


def near(request,idd):
    obj=Vehicle.objects.get(vehicle_id=idd)
    context={
        'lat':obj.latitude,
        'lon':obj.longitude
    }
    return render(request,'tracking/track.html',context)


