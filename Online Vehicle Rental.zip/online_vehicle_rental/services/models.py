from django.db import models
from provider.models import Provider
# Create your models here.

class Services(models.Model):
    services_id = models.AutoField(primary_key=True)
    vehicle_type = models.CharField(max_length=45)
    type_of_services = models.CharField(db_column='Type_of_services', max_length=45)  # Field name made lowercase.
    #provider_id = models.IntegerField()
    provider= models.ForeignKey(Provider, on_delete=models.CASCADE)


    class Meta:
        managed = False
        db_table = 'services'
