from django.conf.urls import url
from book_services import views

urlpatterns=[
             url('sev_book/', views.book_sev),
             url('book_post/(?P<idd>\w+)',views.post_book),
             url('book_user/(?P<idd>\w+)',views.user_book)
]