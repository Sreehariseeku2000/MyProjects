from django.db import models
from user_reg.models import UserReg
from vehicle.models import Vehicle

# Create your models here.


class BookServices(models.Model):
    service_book_id = models.AutoField(primary_key=True)
    service_id = models.IntegerField()
    #user_id = models.IntegerField()
    user=models.ForeignKey(UserReg,on_delete=models.CASCADE,null=True)
    book_date = models.DateField()
    #vehicle_id = models.IntegerField()
    vehicle=models.ForeignKey(Vehicle,on_delete=models.CASCADE)
    time = models.TimeField()
    type=models.CharField(max_length=45)





    class Meta:
        managed = False
        db_table = 'book_services'

